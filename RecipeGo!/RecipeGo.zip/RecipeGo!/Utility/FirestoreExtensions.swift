//
//  FirestoreExtensions.swift
//  RecipeGo!
//
//  Created by Matilda on 10/15/22.
//

import Foundation
import FirebaseFirestore
import FirebaseFirestoreSwift


private extension DocumentReference {
    func setData<T: Encodable>(from value: T) async throws {
        return try await withCheckedThrowingContinuation { continuation in
            try! setData(from: value) { error in
                if let error = error {
                    continuation.resume(throwing: error) // error thrown if problem with model
                    return
                }
                continuation.resume() // all other errors passed to completion handler
            }
        }
    }
}

extension Query {
    func getDocuments<T: Decodable>(as type: T.Type) async throws -> [T] {
        let snapshot = try await getDocuments()
        return snapshot.documents.compactMap { document in
            try! document.data(as: type)
        }
    }
}
